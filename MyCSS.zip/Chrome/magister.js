var grades = document.getElementsByClassName("grade");
var grades_negative = 0;
var grades_positive = 0;
var averages_negative = 0;
var grades_average = []
for (var i = 0; i < grades.length; i++) {
	if(document.getElementsByClassName("grade")[i].innerText.replace(",", ".") <= 5.4 && !isNaN(parseInt(document.getElementsByClassName("grade")[i].innerText))) {
		document.getElementsByClassName("grade")[i].style.setProperty("background-color", "#ffc4c4", "important");
		grades_negative++;
		if(document.getElementsByClassName("grade")[i].classList.contains("gemiddeldecolumn")) {
			averages_negative++;
		}
	} else if(!isNaN(parseInt(document.getElementsByClassName("grade")[i].innerText))) {
		grades_positive++;
	} 
	if(!isNaN(parseInt(document.getElementsByClassName("grade")[i].innerText))) {
		grades_average.push(parseInt(document.getElementsByClassName("grade")[i].innerText))
	}
}
var grade_average = 0
grades_average.forEach(grade => {
	grade_average = grade_average + grade
});

var grade_average = Math.round(grade_average / grades_average.length)
console.info(`Cijfers gehighlight. ${grades_negative} onvoldoendes totaal, ${averages_negative} daarvan zijn in je gemiddelde en ongeveer ${Math.floor(averages_negative / 2)} cijfers waar je aandacht aan moet besteden. Je hebt ${grades_positive} voldoendes en je totale gemiddelde is een ${grade_average}`)