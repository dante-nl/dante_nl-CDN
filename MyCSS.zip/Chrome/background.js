chrome.tabs.onReplaced.addListener(function() {
	chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		thisTab = tabs[0]
		applyCSS(thisTab)
	})
})

chrome.tabs.onUpdated.addListener(function() {
	chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		thisTab = tabs[0]
		applyCSS(thisTab)
	})
})

function applyCSS(activeTab) {
	url = activeTab.url
	urlObj = new URL(url);
	url_origin = urlObj.origin
	chrome.storage.local.get(url_origin, function(data) {
		console.log(data[url_origin])
		css = data[url_origin]
		chrome.scripting.insertCSS(
			{
				css: css,
				target: {
					tabId: activeTab.id,
					allFrames: true
				}
			}
		)
	})
}