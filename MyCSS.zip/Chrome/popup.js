async function getCurrentTab() {
	let queryOptions = { active: true, currentWindow: true };
	let [tab] = await chrome.tabs.query(queryOptions);
	return tab.id;
}
function tab() {
	chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		activeTab = tabs[0]
		return activeTab
	})
}

function getString(length) {
	var result = '';
	var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	var charactersLength = characters.length;
	for (var i = 0; i < length; i++) {
		result += characters.charAt(Math.floor(Math.random() *
			charactersLength));
	}
	return result;
}

function trashClicked(url, id) {
	// alert(url)
	// alert(id)
	// var slides = document.getElementsByClassName("trash");
	// for (var i = 0; i < slides.length; i++) {
	// 	// Distribute(slides.item(i));
	// 	// alert(i.url)
	// 	thisObj = document.getElementsByClassName("trash")[i]
	// 	alert(thisObj.getAttribute("url"))
	// }
	chrome.storage.local.remove([url])
	location.reload();
}

// Listing URLs
chrome.tabs.query({ currentWindow: true, active: true }, async function (tabs) {
	const all = await chrome.storage.local.get();
	loop_times = 0
	for (const [key, val] of Object.entries(all)) {
		loop_times++
		random_string = getString(5)
		elem = document.createElement("div")
		elem.className = "item"
		elem.insertAdjacentHTML("beforeEnd", `<h1>${key}<i class="fa-solid fa-trash trash" url="${key}" id="${random_string}"></i></h1>`)
		elem.addEventListener("click", () => {
			trashClicked(key, random_string)
		})
		document.getElementById("css-codes").appendChild(elem)
	}
	if (loop_times == 0) {
		elem = document.createElement("div")
		elem.className = "item"
		elem.insertAdjacentHTML("beforeEnd", `<h1>No sites! :(</h1><h3>Why not add your CSS for one? Just add it with the coding field above!</h3>`)
		elem.addEventListener("click", () => {
			trashClicked(key, random_string)
		})
		document.getElementById("css-codes").appendChild(elem)
	}
	activeTab = tabs[0]
	const re = /^chrome:\/\//;
	if (re.test(activeTab.url) == true) {
		document.getElementById("submit").disabled = true
		document.getElementById("css-input").innerText = "Chrome URLs are not supported!"
		return
	} else {
		document.getElementById("submit").disabled = false
	}
})

// Adding CSS to input, if any
chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
	activeTab = tabs[0]
	url = activeTab.url
	urlObj = new URL(url);
	url_origin = urlObj.origin

	chrome.storage.local.get(url_origin, function (data) {
		if (typeof data[url_origin] !== "undefined") {
			css = data[url_origin]
			css = css_beautify(css, { indent_size: 2, space_in_empty_paren: true})
			document.getElementById("css-input").value = css
		}
	})
})

// Inserting CSS after submit click
async function submitClicked() {
	chrome.tabs.query({ currentWindow: true, active: true }, async function (tabs) {
		activeTab = tabs[0]
		chrome.scripting.insertCSS(
			{
				css: document.getElementById('css-input').value,
				target: {
					tabId: activeTab.id,
					allFrames: true
				}
			}
		)
		url = activeTab.url,
		urlObj = new URL(url);
		css = document.getElementById('css-input').value
		save_content = {
			[urlObj.origin]: css
		}
		chrome.storage.local.set(save_content)	
	})
}
document.getElementById("submit").addEventListener("click", submitClicked)