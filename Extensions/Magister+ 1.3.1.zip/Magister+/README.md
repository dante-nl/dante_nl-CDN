# Magister+
## Verbeteringen van Magister

Magister+ bevat handige nieuwe features, zoals de mogelijkheid om bepaalde lessen te markeren als belangerijk en om je totale gemiddelde te zien.

* Onvoldoendes makkelijker te zien in je cijfer overzicht*
* Totale gemiddelde zichtbaar in cijfer overzicht*
* Shortcuts naar andere webpagina's in "Vandaag"*
* Verbeterde kleuren*
* Notities in "Vandaag"
* Mogelijkheid om lessen als belangrijk te markeren