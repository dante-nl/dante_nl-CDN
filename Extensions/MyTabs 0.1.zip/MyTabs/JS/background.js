// TODO: Make a page to manage all open tabs
// ? Maybe make support for multiple windows? Currently kind of works, but it does not automatically focuss on the right window

colors = ["grey", "red", "yellow", "green", "pink", "purple", "cyan", "orange"]

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
	if(changeInfo["status"] == "complete") {
		if ("groupId" in changeInfo == false) {
			combineSameURLS()
		}
	}
});


chrome.tabs.onActivated.addListener(async (activeInfo) => {
	var storage = await chrome.storage.sync.get("-AUTOCOMPRESS")
	if (storage["-AUTOCOMPRESS"] == true) {
		setTimeout(async() => {
			await compressAllTabs(activeInfo)
			// The old listener handler moves here
		}, 100);
	}
});

async function getRandomColor() {
	// get a random color from the list of colors 
	var storage = await chrome.storage.sync.get()
	var userColors = storage["-COLORS"]
	if (Array.isArray(storage["-COLORS"]) == false || storage["-COLORS"].length == 0) {
		userColors = ["grey", "red", "yellow", "green", "pink", "purple", "cyan", "orange"]
		// return ["grey", "red", "yellow", "green", "pink", "purple", "cyan", "orange"]
	}
	return userColors[Math.floor(Math.random() * userColors.length)]
}

async function combineSameURLS() {
	chrome.tabs.query({}, async function (tabs) {
		taburls = {}
		for (const tab of tabs) {
			if (tab.url.startsWith("chrome://") == false && tab.url.startsWith("chrome-extension://") == false) {
				var hostname = new URL(tab.url).hostname;
				if (tab.groupId == -1) {
					chrome.tabGroups.query({}, async (groups) => {
						// colors = ["grey", "blue", "red", "yellow", "green", "pink", "purple", "cyan", "orange"]
						var groupFound = false
						for (const group of groups) {
							if (group.title == hostname) {
								// make tab join group
								await chrome.tabs.group({
									tabIds: tab.id,
									groupId: group.id
								});
								var groupFound = true
							}
						}
					})
				}
			// }
			} else {
				// move chrome tab to special category
				var storage = await chrome.storage.sync.get("-CHROME")
				if (storage["-CHROME"] == true) {
					var chromeGroup = await chrome.tabGroups.query({ title: "System" })
					if (chromeGroup.length == 1) {
						// group already exists
						chrome.tabs.group({
							tabIds: tab.id,
							groupId: chromeGroup[0].id
						})
					} else {
						// no group yet
						var newGroup = await chrome.tabs.group({
							tabIds: tab.id
						})
						await chrome.tabGroups.update(newGroup, {
							collapsed: false,
							color: "blue",
							title: "System"
						});
					}
				}
			}
		}

		//// updating groups
		//? might not be used 
		ungrouplist = []
		joingroups = {}

		//* ungroup invalid tabs
		var groups = await chrome.tabGroups.query({})
		var invalidTabs = []
		for (const group of groups) {
			var tabsFound = await chrome.tabs.query({groupId: group.id})
			for (const tab of tabsFound) {
				var hostname = new URL(tab.url).hostname;
				// console.log()
				if (group.title != hostname) {
					if(group.title == "System") {
						if (tab.url.startsWith("chrome://") == false && tab.url.startsWith("chrome-extension://") == false) {
							invalidTabs.push(tab.id)
						}
					} else {
						invalidTabs.push(tab.id)
					}
				}
			}
		}
		if(invalidTabs.length >= 1) {
			await chrome.tabs.ungroup(invalidTabs)
		}


		//* merge all tabs with same hostname
		var ungrouppedTabs = await chrome.tabs.query({ groupId: -1 })
		var hostnames = []
		for (let i = 0; i < ungrouppedTabs.length; i++) {
			var ungrouppedObj = await chrome.tabs.get(ungrouppedTabs[i].id)
			if (ungrouppedObj.url.startsWith("chrome://") == false && ungrouppedObj.url.startsWith("chrome-extension://") == false) {
				var hostname = new URL(ungrouppedObj.url).hostname;
				if (hostname in hostnames == false) {
					hostnames[hostname] = [ungrouppedObj.id]
				} else {
					hostnames[hostname].push(ungrouppedObj.id)
				}
			} else {
				// if it's a chrome:// url, move to special category
				var storage = await chrome.storage.sync.get("-CHROME")
				if (storage["-CHROME"] == true) {
					var chromeGroup = await chrome.tabGroups.query({ title: "System" })
					if(chromeGroup.length == 1) {
						// group already exists
						chrome.tabs.group({
							tabIds: ungrouppedTabs[i].id,
							groupId: chromeGroup[0].id
						})
					} else {
						// no group yet
						var newGroup = await chrome.tabs.group({
							tabIds: ungrouppedTabs[i].id
						})
						await chrome.tabGroups.update(newGroup, {
							collapsed: false,
							color: "blue",
							title: "System"
						});

						await chrome.tabGroups.move(newGroup, { index: 0 })
					}
				}
			}
		}

		// console.warn(hostnames)
		for (const hostname in hostnames) {
			var storage = await chrome.storage.sync.get("-INSTA")
			if (storage["-INSTA"] == true) {
				lengthBeforeNewTab = 1
			} else {
				lengthBeforeNewTab = 2
			}
			// console.error(hostnames[hostname].length)
			if (hostnames[hostname].length >= 1) {
				// loop all tab groups to see if one fits with hostname
				matchGroup = await chrome.tabGroups.query({ title: hostname })

				if (matchGroup.length == 1) {
					// 1 group is found, so let's add our tabs
					chrome.tabs.group({
						tabIds: hostnames[hostname],
						groupId: matchGroup[0].id
					})
				} else if (matchGroup.length > 1) {
					// two or more groups with the hostname are found, so let's merge!
					mergeUrls = []
					for (let i = 0; i < matchGroup.length; i++) {
						urlsInGroup = await chrome.tabs.query({ groupId: matchGroup[i].id })
						for (let i2 = 0; i2 < urlsInGroup.length; i2++) {
							mergeUrls.push(urlsInGroup[i2].id)
						}
					}
					// await chrome.tabs.ungroup({
					// 	tabIds: mergeUrls
					// })
					var newGroup = await chrome.tabs.group({
						tabIds: mergeUrls
					})

					await chrome.tabGroups.update(newGroup, {
						collapsed: false,
						color: await getRandomColor(),
						title: hostname
					});
				} else {
					if (hostnames[hostname].length >= lengthBeforeNewTab) {
						// no groups found, so let's add them!
						var createdGroup = await chrome.tabs.group({
							tabIds: hostnames[hostname]
						})
						await chrome.tabGroups.update(createdGroup, {
							collapsed: false,
							color: await getRandomColor(),
							title: hostname
						});
					}
				}
			}
		}
	})
}


// compress all tabs except for one currently on
async function compressAllTabs(activeInfo) {
	var tab = await chrome.tabs.get(activeInfo["tabId"])
	var tabGroups = await chrome.tabGroups.query({})
	var groupsToBeCompressed = []
	for (group of tabGroups) {
		if (group.id != tab.groupId) {
			groupsToBeCompressed.push(group.id)
		}
	}


	for (let i = 0; i < groupsToBeCompressed.length; i++) {
		await chrome.tabGroups.update(groupsToBeCompressed[i], {
			collapsed: true
		});
	}
}