//* Automatically group chrome tabs

chrome.storage.sync.get("-CHROME", function (items) {
	if (items["-CHROME"] == true) {
		document.getElementById("ChromeToggle").checked = true
	}
})

function ChromeStatus() {
	chrome.storage.sync.get("-CHROME", function (items) {
		console.log(items["-CHROME"])
	});
}

function capitalizeWord(string) {
	return string.charAt(0).toUpperCase() + string.slice(1);
}

document.getElementById("ChromeToggle").oninput = function () { toggleChrome() };
function toggleChrome() {
	chrome.storage.sync.get("-CHROME", function (items) {
		if (items["-CHROME"] == true) {
			chrome.storage.sync.remove(["-CHROME"])
		} else {
			save_content = {
				"-CHROME": true
			}
			chrome.storage.sync.set(save_content)
		}
	})
}

//* Instantly create new groups

chrome.storage.sync.get("-INSTA", function (items) {
	if (items["-INSTA"] == true) {
		document.getElementById("InstaToggle").checked = true
	}
})

function InstaStatus() {
	chrome.storage.sync.get("-INSTA", function (items) {
		console.log(items["-INSTA"])
	});
}

document.getElementById("InstaToggle").oninput = function () { toggleInsta() };
function toggleInsta() {
	chrome.storage.sync.get("-INSTA", function (items) {
		if (items["-INSTA"] == true) {
			chrome.storage.sync.remove(["-INSTA"])
		} else {
			save_content = {
				"-INSTA": true
			}
			chrome.storage.sync.set(save_content)
		}
	})
}

//* Automatically compress inactive tab groups

chrome.storage.sync.get("-AUTOCOMPRESS", function (items) {
	if (items["-AUTOCOMPRESS"] == true) {
		document.getElementById("AutoCompressToggle").checked = true
	}
})

function AutoCompressStatus() {
	chrome.storage.sync.get("-AUTOCOMPRESS", function (items) {
		console.log(items["-AUTOCOMPRESS"])
	});
}

document.getElementById("AutoCompressToggle").oninput = function () { toggleAutoCompress() };
function toggleAutoCompress() {
	chrome.storage.sync.get("-AUTOCOMPRESS", function (items) {
		console.log(items["-AUTOCOMPRESS"])
		if (items["-AUTOCOMPRESS"] == true) {
			chrome.storage.sync.remove(["-AUTOCOMPRESS"])
		} else {
			save_content = {
				"-AUTOCOMPRESS": true
			}
			chrome.storage.sync.set(save_content)
		}
	})
}

//* List active and inactive colors

function ColorStatus() {
	chrome.storage.sync.get("-COLORS", function (items) {
		console.log(items["-COLORS"])
	});
}

function listColors() {
	chrome.storage.sync.get("-COLORS", function (items) {
		// valid colors:
		// grey, blue, red, yellow, green, pink, purple, cyan, orange
		colors = ["grey", "blue", "red", "yellow", "green", "pink", "purple", "cyan", "orange"]
		console.log(items["-COLORS"])
		if (items["-COLORS"] !== undefined) {
			for (color of items["-COLORS"]) {
				console.log(color)
				// if (color == "grey") {
				elem = document.createElement("div")
				elem.className = "color-block enabled"
				elem.insertAdjacentHTML("beforeEnd", `<p id="${color}"><span class="circle ${color}"></span>${capitalizeWord(color)}</p>`)

				document.getElementById("enabled-colors").appendChild(elem)
				elem.addEventListener("click", (function (color) {
					return async function () {
						await toggleColor(color);
					};
				})(color));

				// remove item from colors
				const index = colors.indexOf(color);

				if (index !== -1) {
					colors.splice(index, 1);
				}
				// }
			}
		}
		for (color of colors) {
			elem = document.createElement("div")
			elem.className = "color-block disabled"
			elem.insertAdjacentHTML("beforeEnd", `<span class="circle ${color}"></span><p id="${color}">${capitalizeWord(color)}</p>`)

			document.getElementById("disabled-colors").appendChild(elem)
			elem.addEventListener("click", (function (color) {
				return async function () {
					await toggleColor(color);
				};
			})(color));
		}
	})
}

async function toggleColor(color) {
	chrome.storage.sync.get("-COLORS", function (items) {
		console.log(items["-COLORS"])
		if (Array.isArray(items["-COLORS"]) == false || items["-COLORS"].length == 0) {
			colorlist = []
		} else {
			colorlist = items["-COLORS"]
		}
		console.log(colorlist.indexOf(color))
		if (colorlist.indexOf(color) !== -1) {
			// color is enabled, so needs to be removed

			if (colorlist.length-1 == 0) {
				// prevent emtying out list
				// document.getElementById(color).parentElement.style.borderColor = "var(--red)"
			} else {
				document.getElementById(color).parentElement.style.borderColor = "var(--green)"
				colorIndex = colorlist.indexOf(color)
				colorlist.splice(colorIndex, 1)

				save_content = {
					"-COLORS": colorlist.filter(item => item !== color)
				}
				chrome.storage.sync.set(save_content)

				document.getElementById(color).parentElement.remove()

				elem = document.createElement("div")
				elem.className = "color-block disabled"
				elem.insertAdjacentHTML("beforeEnd", `<span class="circle ${color}"></span><p id="${color}">${capitalizeWord(color)}</p></span> `)

				document.getElementById("disabled-colors").appendChild(elem)
				elem.addEventListener("click", (function (color) {
					return async function () {
						await toggleColor(color);
					};
				})(color));
			}
		} else {
			// add color to array
			colorlist.push(color)
			save_content = {
				"-COLORS": colorlist
			}

			chrome.storage.sync.set(save_content)

			document.getElementById(color).parentElement.remove()

			elem = document.createElement("div")
			elem.className = "color-block enabled"
			elem.insertAdjacentHTML("beforeEnd", `<p id="${color}"><span class="circle ${color}"></span>${capitalizeWord(color)}</p></span>`)

			document.getElementById("enabled-colors").appendChild(elem)
			elem.addEventListener("click", (function (color) {
				return async function () {
					await toggleColor(color);
				};
			})(color));
		}
	})
}

listColors()