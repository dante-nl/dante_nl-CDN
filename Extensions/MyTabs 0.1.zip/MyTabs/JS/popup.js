// default functions

function getString(length) {
	var result = '';
	var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	var charactersLength = characters.length;
	for (var i = 0; i < length; i++) {
		result += characters.charAt(Math.floor(Math.random() *
			charactersLength));
	}
	return result;
}

function truncate(input, length) { 
	if (input.length <= length) {
		return input;
	} if (length < 3) {
		return input.substring(0, length); 
	}
	return input.substring(0, length - 3) + '...'; }



// when page loaded, add everything here

window.addEventListener("load", async function () {
	var tabGroups = {}
	var ungroupedTabs = []

	tabs = await chrome.tabs.query({})
	for (tab of tabs) {
		var hostname = new URL(tab.url).hostname;
		if (tab.groupId != -1) {
			// console.log(tab.groupId)
			parentGroup = await chrome.tabGroups.get(tab.groupId)
			if (parentGroup.title in tabGroups == false) {
				tabGroups[parentGroup.title] = {"groupId": tab.groupId, "tabs": [{
					"id": tab.id,
					"hostname": hostname,
					"url": tab.url,
					"title": tab.title
				}]}
			} else {
				tabGroups[parentGroup.title]["tabs"].push({
					"id": tab.id,
					"hostname": hostname,
					"url": tab.url,
					"title": tab.title
				})
			}
		} else {
			ungroupedTabs.push({
				"id": tab.id,
				"hostname": hostname
			})
		}
	}

	var anytabs = false

	for (var tab in ungroupedTabs) {

	}

	document.getElementById("group_manager").innerHTML = ""
	for (var tabGroup in tabGroups) {
		var randomId = getString(10)
		groupElem = document.createElement("h1")
		groupElem.innerHTML = `${tabGroup} <i class="fa-regular fa-circle-xmark close" id="${randomId}"></i>`
		document.getElementById("group_manager").appendChild(groupElem)


		document.getElementById(randomId).addEventListener("click", (function (groupId = tabGroups[tabGroup]["groupId"]) {
			return async function () {
				await closeGroup(groupId);
			};
		})(tabGroups[tabGroup]["groupId"], randomId));

		for (item of tabGroups[tabGroup]["tabs"]) {
			anytabs = true
			random_string = getString(5)
			elem = document.createElement("div")
			elem.className = "site"
			elem.insertAdjacentHTML("beforeEnd", `
			<p>${truncate(item["title"], 45)}</p>
			<span>
				<i class="fa-solid fa-arrow-up-right-from-square" id="${random_string}-open"></i>
				<i class="fa-regular fa-circle-xmark close" id="${random_string}"></i>
			</span`)

			document.getElementById("group_manager").appendChild(elem)
			document.getElementById(random_string).addEventListener("click", (function (tabId, jsId) {
				return async function () {
					await closeTab(tabId, jsId);
				};
			})(item["id"], random_string));
			document.getElementById(`${random_string}-open`).addEventListener("click", (function (tabId) {
				return async function () {
					await switchTab(tabId);
				};
			})(item["id"]));
		}
	}
});

//* when the user wants tom close group, do it
async function closeGroup(groupdId) {
	tabs = await chrome.tabs.query({ groupId: groupdId })
	var closingTabs = []
	for(tab of tabs) {
		closingTabs.push(tab.id)
	}
	await chrome.tabs.remove(closingTabs)
	location.reload()
}

//* when the user wants to switch tab, do it
async function switchTab(tabId) {
	// tab = await chrome.tabs.get(tabId)
	chrome.tabs.update(tabId, {
		active: true
	})
}

//* when user wants to close tab, do it
async function closeTab(tabId, jsId) {
	await chrome.tabs.remove(tabId)
	location.reload()
}